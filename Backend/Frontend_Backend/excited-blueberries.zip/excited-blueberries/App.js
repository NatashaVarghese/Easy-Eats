/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React from 'react';
import { StyleSheet, Text, View, TextInput, Button } from 'react-native';
import axios from 'axios';

const url = 'http://142.1.200.140:5000';
const http = axios.create({
  baseURL: url,
});

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      input: '',
      text: 'hello',
    };
  }


  addingrediant() {
    const {input}=this.state
    this.setState({ text:"text" })
    http.post('/MakeRecipe/', {food:input})
    .then((response) => {this.setState({text:response.data})
    
    }
    );
  }

  makeRecipe() {
    this.setState({ text:"other text" })
    http.post('/recipe/', {})
    .then((response) => {this.setState({text:response})}
    ).then(json => console.log(json));
  }
  render() {
    return (
      <View style={styles.container}>
        <Text>{this.state.text}</Text>
        <TextInput onChangeText={val => this.setState({ input: val })} />
        <Button title="Add ingredient" onPress={() => this.addingrediant()} />
        <Button title="Make Recipe" onPress={() => this.makeRecipe()} />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundcolor: '#ffffff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
