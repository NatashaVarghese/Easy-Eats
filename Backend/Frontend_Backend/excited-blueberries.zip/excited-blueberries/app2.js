/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React from 'react';
import {StyleSheet, Text, View, TextInput,Button} from 'react-native';


export default class App extends React.Component {
    render(){
        return (
          <View style={styles.container}>
          <Text>Messsage</Text>
          <TextInput />
          <Button title='Add ingredient' onPress[{}=>{}] />
          <Button title='Make Recipe' onPress[{}=>{}] />
          </View>
        }
        );
    }
}


const styles = StyleSheet.create{{

container:{
  flex:1,
  backgroundcolor: "#ffffff"
  alignalignItems:'center',
  justifyContent:'center'
}

}
}